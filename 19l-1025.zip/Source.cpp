#include<iostream>
#include<conio.h>
#include<string>
#include<fstream>
using namespace std;
class name
{
	char *fname;
	char *lname;
public:
	name()
	{
		fname = nullptr;
		lname = nullptr;
	}
	void setname(string a, string b)
	{

		int q = a.length();
		int w = b.length();
		fname = new char[q + 1];
		lname = new char[w + 1];
		for (int c = 0; c < q; ++c)
		{
			fname[c] = a[c];
		}
		fname[q] = '\0';
		for (int d = 0; d < w; ++d)
		{
			lname[d] = b[d];
		}
		lname[w] = '\0';
	}
	char *gtna()
	{
		return fname;
	}
	char *gtln()
	{
		return lname;
	}
	void print()
	{
		cout << "Person Name: " << fname << " " << lname << "   ";
	}
	~name()
	{
		delete []fname;
		delete []lname;
		cout << "Name Destructor called " << endl;
	}



	friend ostream & operator <<(ostream & output, name & nobj);
};
ostream & operator <<(ostream & output, name & nobj)
{
	output << nobj.fname << "  " << nobj.lname << endl;
	return output;
}
class date
{
	int day;
	int month;
	int year;
public:
	date()
	{
		day = 0;
		month = 0;
		year = 0;
	}
	void setdate(int d1, int m1, int y1)
	{
		day = d1;
		month = m1;
		year = y1;
	}
	int getday()
	{
		return day;
	}
	int getmonth()
	{
		return month;
	}
	int getyear()
	{
		return year;
	}
	void printdate()
	{
		cout << "Date:" << day << " " << month << " " << year << "   ";
	}
	~date()
	{
		cout << "Date close" << endl;
	}
	friend	ostream & operator <<(ostream & output, date & dobj);
};
ostream & operator <<(ostream & output, date & dobj)
{
	output << dobj.day << "  " << dobj.month << "  " << dobj.year << endl;
	return output;
}
class time
{
	int hour;
	int min;
	int sec;
public:
	time()
	{
		hour = 0;
		min = 0;
		sec = 0;
	}
	time(int ah1, int ah2, int ah3)
	{
		hour = ah1;
		min = ah2;
		sec = ah3;
	}
	void setitme(int at, int bt, int ct)
	{
		hour = at;
		min = bt;
		sec = ct;
	}
	int gthour()
	{
		return hour;
	}
	int gtmin()
	{
		return min;
	}
	int gtsec()
	{
		return sec;
	}
	void printime()
	{
		cout << hour << "  " << min << "  " << sec << " ";
	}
	~time()
	{
		cout << "Time Closed" << endl;
	}
};
class person
{
	name pname;
	date dob;
	int age;
	int nid;
public:
	person()
	{
		age = 0;
	}
	person(string ab, string ba, int a1, int a2, int a3, int a4, int a5)
	{
		pname.setname(ab, ba);
		dob.setdate(a1, a2, a3);
		age = a4;
		nid = a5;
	}
	void printperson()
	{
		pname.print();
		dob.printdate();
		cout << "Age is: " << age << "   " << "Id is: " << nid << "  ";
	}
	char *ppname()
	{
		return pname.gtna();
	}
	char *plname()
	{
		return pname.gtln();
	}
	int gtpday()
	{
		return dob.getday();
	}
	int gtpmonth()
	{
		return dob.getmonth();
	}
	int gtpyear()
	{
		return dob.getyear();
	}
	int gtpage()
	{
		return age;
	}
	int gtppid()
	{
		return nid;
	}
	~person()

	{

		cout << "Person closed" << endl;
	}
	friend ostream & operator <<(ostream & out, person & ob);
};
ostream & operator <<(ostream & out, person & ob)
{
	out << ob.pname << "  " << ob.dob << "  " << ob.age << "  " << ob.nid << endl;
	return out;
}
class precord
{

	date visitdate;
	int assigneddoc;
	int feepaid;
	char *disease;
public:
	precord()
	{
		disease = nullptr;
		feepaid = 0;
	}
	precord(string da, int db, int dc, int dd, int df, int ff)
	{
		int sz = da.length();
		disease = new char[sz + 1];
		for (int q = 0; q < sz; ++q)
		{
			disease[q] = da[q];
		}
		disease[da.length()] = '\0';

		visitdate.setdate(db, dc, dd);
		assigneddoc = df;
		feepaid = ff;
	}
	void pd()
	{
		cout << disease << "  ";
		visitdate.printdate();
		cout << assigneddoc << "  " << feepaid << endl;

	}
	char *rtdis()
	{
		return disease;
	}
	int rtd()
	{
		return visitdate.getday();
	}
	int rtm()
	{
		return visitdate.getmonth();
	}
	int rty()
	{
		return visitdate.getyear();
	}
	int rtdid()
	{
		return assigneddoc;
	}
	int rtfee()
	{
		return feepaid;
	}
	~precord()
	{
		delete[]disease;	
		cout << "Precod Closed " << endl;
	}

};
class patient : public person
{
	int pid;
	precord **history;

	int indr;
	int ny;
	int stt;
public:
	patient()
	{
		pid = 0;
		indr = 0;
		stt = 0;
	}
	patient(string cb, string ca, int c1, int c2, int c3, int c4, int c5, int pd) : person(cb, ca, c1, c2, c3, c4, c5)
	{
		pid = pd;
		history = new precord*[1];
		ny = 1;
		stt = 0;
	}
	void print()
	{
		person::printperson();
		cout << "Paitient id: " << pid << endl;
	}
	int getid()
	{
		return pid;
	}
	void setrd(string rd, int rd1, int rd2, int rd3, int rd4, int inc, int f1)
	{
		if (inc == 1)
		{
			history[0] = new precord(rd, rd1, rd2, rd3, rd4, f1);
		}
		if (inc >= 2)
		{
			precord **temp;
			temp = new precord*[inc - 1];
			for (int az = 0; az < inc - 1; ++az)
			{
				temp[az] = history[az];
			}
			delete[]history;
			history = nullptr;
			history = new precord*[inc];
			for (int we = 0; we < inc - 1; ++we)
			{
				history[we] = temp[we];
			}
			history[inc - 1] = new precord(rd, rd1, rd2, rd3, rd4, f1);
			delete[]temp;
			temp = nullptr;
		}
		stt = 1;
	}
	int rtin()
	{
		return ny;
	}
	void inpc()
	{
		++ny;
	}

	void pprd()
	{
		for (int rt = 0; rt < ny - 1; ++rt)
		{
			history[rt]->pd();

		}
	}
	void prd(int w)
	{
		history[w]->pd();
	}
	char *btdi(int s)
	{
		return history[s]->rtdis();
	}
	int btd(int q)
	{
		return history[q]->rtd();
	}
	int btm(int w)
	{
		return history[w]->rtm();
	}
	int bty(int e)
	{
		return history[e]->rty();
	}
	int btid(int y)
	{
		return history[y]->rtdid();
	}
	int btfes(int o)
	{
		return history[o]->rtfee();
	}
	int gtst()
	{
		return stt;
	}
	~patient()
	{
		cout << "Patient CLosed Precod " << endl;
		delete[]history;
	}
	friend ostream & operator <<(ostream & output, patient & otj);
};
ostream & operator << (ostream & output, patient & otj)
{

	output << otj.pid;
	return output;
}
class doctor : public person
{
	int did;
	char *specialization;
	int *paitientid;
	int dar;
	int sat;
public:
	doctor()
	{
		did = 0;
		specialization = nullptr;
		paitientid = nullptr;
		dar = 1;
		sat = 0;
	}
	doctor(string tb, string ta, int t1, int t2, int t3, int t4, int t5, string ty, int tt) : person(tb, ta, t1, t2, t3, t4, t5)
	{
		did = tt;
		int sz1 = ty.length();
		specialization = new char[sz1 + 1];
		for (int w = 0; w < sz1; ++w)
		{
			specialization[w] = ty[w];
		}
		specialization[ty.length()] = '\0';
		paitientid = new int[1];
		dar = 1;
		sat = 0;
	}
	void print()
	{
		person::printperson();
		cout << "Doctor's Id: " << did << "  specialization: " << specialization << endl;
	}
	void printdoc()
	{
		cout << specialization << "   " << did << endl;
	}
	int getdid()
	{

		return did;
	}
	int getin()
	{

		return dar;
	}
	void inar()
	{

		++dar;

	}
	void rcd(int ar, int pti)
	{
		if (ar <= 1)
		{
			paitientid[0] = pti;
		}
		if (ar >= 2)
		{
			int *tpr = new int[ar - 1];
			for (int te = 0; te < ar - 1; ++te)
			{
				tpr[te] = paitientid[te];
			}
			delete[]paitientid;
			paitientid = nullptr;
			paitientid = new int[ar];
			for (int dt = 0; dt < ar - 1; ++dt)
			{
				paitientid[dt] = tpr[dt];

			}
			paitientid[ar - 1] = pti;
			delete[]tpr;
			tpr = nullptr;
		}
		sat = 1;
	}
	char *gtspeca()
	{
		return specialization;
	}
	int getsat()
	{
		return sat;
	}
	void dhi()
	{
		for (int dq = 0; dq < dar - 1; ++dq)
		{
			cout << paitientid[dq] << endl;
		}

	}
	int gthisto(int d)
	{
		return paitientid[d];
	}
	~doctor()
	{
		delete[]specialization;
		delete[]paitientid;
		cout << "Doctor Closed " << endl;
	}
};
class appointment
{
	char *diseas;
	int pid;
	int ditd;
	date apdate;
	time aptime;
	int token_no;
	int fee;
	bool status;
public:
	appointment()
	{
		diseas = nullptr;
		pid = 0;
		ditd = 0;
		token_no = 0;
		status = false;
	}
	appointment(string at, int pi, int di, int q1, int q2, int q3, int tkn, int apt1, int apt2, int apt3)
	{
		int z = at.length();
		diseas = new char[z + 1];
		for (int q = 0; q < z; ++q)
		{
			diseas[q] = at[q];
		}
		diseas[at.length()] = '\0';
		pid = pi;
		ditd = di;
		apdate.setdate(q1, q2, q3);
		token_no = tkn;

		status = false;
		aptime.setitme(apt1, apt2, apt3);
	}
	void setfee(int fa)
	{
		fee = fa;
		status = true;
	}
	int getptid()
	{
		return pid;
	}
	int gtd()
	{
		return ditd;
	}
	int gtda()
	{
		int m1 = apdate.getday();
		return m1;
	}
	int gtmo()
	{
		int m2 = apdate.getmonth();
		return m2;
	}
	int gtyr()
	{
		int m3 = apdate.getyear();
		return m3;
	}
	char* getdis()
	{
		return diseas;
	}
	void apprint()
	{
		cout << "Disease " << diseas << "  " << "Patien Id  " << pid << "  ";
		apdate.printdate();
		aptime.printime();
		cout << "  ""Token No " << token_no << "  " << "Fee Status " << fee << "  " << "Status is " << status << endl;
	}
	bool getsta()
	{
		return status;
	}
	int gttkno()
	{
		return token_no;
	}
	int gtvth()
	{
		return aptime.gthour();
	}
	int gtvtm()
	{
		return aptime.gtmin();
	}
	int gtvts()
	{
		return aptime.gtsec();
	}
	~appointment()
	{
		delete[]diseas;
		cout << "appointment closed " << endl;
	}
};
int main()
{
	patient *obj[15];
	doctor *dbj[10];
	appointment *abj[15];
	int seral = 30;
	int turn = 0;
	int spid = 1;
	int pa = 0;
	int da = 0;
	int ta = 0;
	char chose;
	int chk = 0;

	for (int aq = 0; aq < 20; ++aq)
	{
		cout << "To Add New Patient Press 1" << endl;
		cout << "To Add Doctor Press 2" << endl;
		cout << "To Make Appointment Press 3" << endl;
		cout << "To Visit Doctor Press 4" << endl;
		cout << "To Load Saved Data Press 5" << endl;
		cout << "To Check Pending Appointment Of Particular Date Press 6" << endl;
		cout << "To Check Pending Appointment of Particual Doctor Press 7" << endl;
		cout << "To Print details of all patients who visited same doctor but on different days Press 8" << endl;
		cout << "To Print details of all patients, whom a doctor has visited on a particular date Press c" << endl;
		cout << "To Print Complete Detail Of Patient Press p " << endl;
		cout << "To Check Complete Detail of Doctor Press d" << endl;
		cout << "To Print Complete Detail of All Patient and Doctor Press h" << endl;
		cout << "To Save Data Press 9 " << endl;

		chose = _getch();
		if (chose == '5')
		{

			ifstream fin;
			fin.open("Patient.txt");
			while (!fin.eof())
			{
				string s1;
				string s2;
				int s3, s4, s5, s6, s7, s8;
				fin >> s1;
				fin >> s2;
				fin >> s3;
				fin >> s4;
				fin >> s5;
				fin >> s6;
				fin >> s7;
				fin >> s8;

				obj[pa] = new patient(s1, s2, s3, s4, s5, s6, s7, s8);
				
				++pa;
				++seral;
				
			}

			fin.close();
			ifstream din;
			din.open("doctor.txt");
			while (!din.eof())
			{
				string k1;
				string k2;
				int k3;
				int k4;
				int k5;
				int k6;
				int k7;
				string k8;
				int k9;
				din >> k1;
				din >> k2;
				din >> k3;
				din >> k4;
				din >> k5;
				din >> k6;
				din >> k7;
				din >> k8;
				din >> k9;
				dbj[da] = new doctor(k1, k2, k3, k4, k5, k6, k7, k8, k9);

				++da;
				++spid;
			}

			din.close();


			ifstream pin;
			pin.open("appoint.txt");
			while (!pin.eof())
			{
				string ai;
				int ai6;
				int ai1;
				int ai2;
				int ai3;
				int ai4;
				int ai5;
				int ai9, ai7, ai8;
				pin >> ai;
				pin >> ai6;
				pin >> ai1;
				pin >> ai2;
				pin >> ai3;
				pin >> ai4;
				pin >> ai5;
				pin >> ai9;
				pin >> ai7;
				pin >> ai8;
				abj[ta] = new appointment(ai, ai6, ai1, ai2, ai3, ai4, ai5, ai9, ai7, ai8);
				++ta;
				++turn;
			}

			pin.close();
			int idex = 0;
			int ht = 0;
			int hy = 0;
			ifstream his;
			his.open("history.txt");
			while (!his.eof())
			{
				his >> hy;
				for (int a = 0; a < 1; ++a)
				{
					his >> ht;

					if (ht != 9)
					{
						int dp = dbj[hy-1]->getin();

						dbj[hy-1]->rcd(dp, ht);
						dbj[hy-1]->inar();

					}
					if (ht != 9)
					{
						a = -1;
					}

				}
			}
			his.close();
		
			ifstream tin;
			int bv = 0;
			string zx;
			int vf = 0;
			int zx1, zx2, zx3, zx4, zx5, zx6,zx7;
			tin.open("patienthistory.txt");
			while (!tin.eof())
			{			
				tin >> zx7;
				
				for (int q = 0; q < pa; ++q)
				{
					for (int d = 0; d < 1; ++d)
					{
						if (obj[q]->getid() == zx7)
						{
							
							tin >> zx;
							tin >> zx1;
							tin >> zx2;
							tin >> zx3;
							tin >> zx4;
							tin >> zx5;
							tin >> zx6;

							int zu = obj[q]->rtin();

							obj[q]->setrd(zx, zx1, zx2, zx3, zx4, zu, zx5);
							obj[q]->inpc();

							if (zx6 == 8)
							{
								q = 100;
							}
							if (zx6 == 7)
							{
								d = -1;
							}
						}
					}
				}
			}
			
		}

		if (chose == '1')
		{
			string q;
			string w;
			int q1;
			int q2;
			int q3;
			int q4;
			int q5;
			int q6;
			cout << "Enter Patient First Name ";
			cin >> q;
			cout << "Enter Patient Last Name ";
			cin >> w;
			cout << "Enter Date of birth Day ";
			cin >> q1;
			cout << "Enter Date of birth month ";
			cin >> q2;
			cout << "Enter Date of birth Year ";
			cin >> q3;
			cout << "Enter Age ";
			cin >> q4;
			cout << "Enter Patient Id Card No ";
			cin >> q5;
			cout << "Unique Id ";
			q6 = seral;
			cout << q6 << endl;
			obj[pa] = new patient(q, w, q1, q2, q3, q4, q5, q6);


			++pa;
			++seral;
		}
		else if (chose == '2')
		{
			string d1;
			string d2;
			int d3;
			int d4;
			int d5;
			int d6;

			string d9;
			int d11;
			int d12;
			cout << "Enter Doctor's First Name ";
			cin >> d1;
			cout << "Enter Doctor's Last Name ";
			cin >> d2;
			cout << "Enter Date of Birth Day ";
			cin >> d3;
			cout << "Enter Date of Birth Month ";
			cin >> d4;
			cout << "Enter Date of Birth Year ";
			cin >> d5;
			cout << "Enter Doctor Age ";
			cin >> d11;
			cout << "Enter Person Id ";
			cin >> d12;
			cout << "Enter Doctor Specialiazation ";
			cin >> d9;
			cout << "Enter Doctor's Id ";
			d6 = spid;
			cout << d6 << endl;
			dbj[da] = new doctor(d1, d2, d3, d4, d5, d11, d12, d9, d6);
			++da;
			++spid;
		}
		else if (chose == '3')
		{
			string ap;
			int ptid;
			int ap1;
			int ap2;
			int ap3;
			int ap4;
			int ap5;
			int ap81;
			int ap82;
			int ap83;
			for (int yt = 0; yt < 1; ++yt)
			{
				cout << "Enter Patient Id ";
				cin >> ptid;
				for (int y = 0; y < pa; ++y)
				{
					if (obj[y]->getid() == ptid)
					{
						chk = 1;
						y = 20;
					}
				}
				if (chk == 0)
				{
					cout << "Enter Valid Patient Id" << endl;
					yt = -1;
				}
			}
			cout << "Enter disease type " << endl;
			cin >> ap;
			cout << "Enter Day " << endl;
			cin >> ap1;
			cout << "Enter Month " << endl;
			cin >> ap2;
			cout << "Enter Year " << endl;
			cin >> ap3;
			cout << "Doctors Avaible " << endl;
			for (int p1 = 0; p1 < da; ++p1)
			{
				dbj[p1]->printdoc();
			}


			for (int pat = 0; pat < 1; ++pat)
			{
				int dro = 0;
				cout << "Enter Doctor id ";
				cin >> ap5;
				for (int d1 = 0; d1 < da; ++d1)
				{
					if (dbj[d1]->getdid() == ap5)
					{
						d1 = 100;
						dro = 1;
					}
				}

				if (dro == 0)
				{
					--pat;
					cout << "Enter Valid Doctor id" << endl;
				}

			}
			cout << "Enter Time Hour ";
			cin >> ap81;
			cout << "Enter Time min ";
			cin >> ap82;
			cout << "Enter Time Sec ";
			cin >> ap83;
			cout << "Issue Token No " << endl;
			ap4 = turn;
			cout << ap4 << endl;
			chk = 0;
			abj[ta] = new appointment(ap, ptid, ap5, ap1, ap2, ap3, ap4, ap81, ap82, ap83);
			++ta;
			++turn;
		}
		if (chose == '4')
		{

			int charge = 0;
			int stat = 0;
			int next = 0;
			for (int nt = 0; nt < 1; ++nt)
			{

				cout << "Enter Patient Id ";
				cin >> stat;
				for (int ba = 0; ba < ta; ++ba)
				{
					
					if (abj[ba]->getptid() == stat)
					{
						next = 1;
						ba = 100;
					}

				}
				if (next == 0)
				{
					cout << "Enter Valid Patient id";
					nt = -1;
					cout << endl;
				}
			}

			for (int sta = 0; sta < ta; ++sta)
			{
				if (abj[sta]->getptid() == stat)
				{
					cout << "Enter Fees ";
					cin >> charge;
					abj[sta]->setfee(charge);

					abj[sta]->apprint();

					int fs = 0;
					for (int sw = 0; sw < da; ++sw)
					{

						if (abj[sta]->gtd() == dbj[sw]->getdid())
						{

							fs = abj[sw]->gtd();
							int ds = dbj[sw]->getin();

							dbj[sw]->rcd(ds, stat);
							dbj[sw]->inar();
							cout << "Dcotor History " << endl;
							dbj[sw]->dhi();
							sw = 100;

						}
					}
					sta = 100;
				}
			}
			for (int yt = 0; yt < pa; ++yt)
			{
				if (obj[yt]->getid() == stat)
				{
					int ju = 0;
					string temp;
					int h1 = 0;
					int h2 = 0, h3 = 0;
					for (int hj = 0; hj < ta; ++hj)
					{
						if (stat == abj[hj]->getptid())
						{
							ju = abj[hj]->gtd();

							temp = abj[hj]->getdis();
							h1 = abj[hj]->gtda();
							h2 = abj[hj]->gtmo();
							h3 = abj[hj]->gtyr();

							hj = 100;
						}
					}
					int iu = obj[yt]->rtin();
					obj[yt]->setrd(temp, h1, h2, h3, ju, iu, charge);
					obj[yt]->inpc();
					cout << "Patient History " << endl;
					obj[yt]->print();
					obj[yt]->pprd();
					yt = 100;
				}
			}
			int sz1 = 0;
			for (int df = 0; df < ta; ++df)
			{
				if (abj[df]->getsta() != true)
				{
					++sz1;
				}
			}
			appointment *tp[15];

			for (int gh = 0, kj = 0; gh < ta; ++gh)
			{
				if (abj[gh]->getsta() != true)
				{
					tp[kj] = abj[gh];
					++kj;
				}
			}

			for (int gf = 0; gf < ta; ++gf)
			{

				abj[gf] = nullptr;
			}
			for (int jj = 0; jj < sz1; ++jj)
			{
				abj[jj] = tp[jj];
			}
			ta = sz1;
		}
		if (chose == '6')
		{
			int pn1, pn2, pn3;
			cout << "Enter Date Day :";
			cin >> pn1;
			cout << "Enter Date Month :";
			cin >> pn2;
			cout << "Enter Date Year :";
			cin >> pn3;
			cout << "Pending Appointment" << endl;
			for (int oi = 0; oi < ta; ++oi)
			{
				int pncheck = 0;
				if (abj[oi]->gtda() == pn1)
				{
					if (abj[oi]->gtmo() == pn2)
					{
						if (abj[oi]->gtyr() == pn3)
						{
							pncheck = 1;
						}
						else
						{
							pncheck = 2;
						}
					}
					else
					{
						pncheck = 2;
					}
				}
				else
				{
					pncheck = 2;
				}
				if (pncheck == 1)
				{
					abj[oi]->apprint();
				}
			}
		}
		if (chose == '7')
		{
			int mb = 0;
			cout << "Enter Doctor's Id To Check Pending Appointment ";
			cin >> mb;
			for (int nn = 0; nn < ta; ++nn)
			{
				if (abj[nn]->gtd() == mb)
				{
					abj[nn]->apprint();
				}
			}
		}
		if (chose == '8')
		{
			int vc = 0;
			cout << "Enter Doctor's Id to Check Patient Visited Same Doctor On Different Days ";
			cin >> vc;
			
					for (int f = 0; f < pa; ++f)
					{
						for (int g = 0; g < obj[f]->rtin()-1; ++g)
						{

							
							if (obj[f]->btid(g) == vc)
							{
								obj[f]->print();
								obj[f]->pprd();
							}
						}
					
				    }			
		}
		if (chose == 'p')
		{
			int schst;
			cout << "Enter Patient Id To Check Complete Details ";
			cin >> schst;
			for (int vf = 0; vf < pa; ++vf)
			{
				if (obj[vf]->getid() == schst)
				{
					obj[vf]->print();
					obj[vf]->pprd();
					vf = 100;
				}

			}
		}
		if (chose == 'd')
		{
			int dlk = 0;
			cout << "Enter Doctor Id to Check Complete details ";
			cin >> dlk;
			for (int r = 0; r < da; ++r)
			{
				if (dbj[r]->getdid() == dlk)
				{
					dbj[r]->print();
					dbj[r]->dhi();
				}
			}



		}
		if (chose == '9')
		{
			ofstream fout;
			fout.open("Patient.txt");
			for (int pu = 0; pu < pa; ++pu)
			{
				fout << obj[pu]->ppname() << " ";
				fout << obj[pu]->plname() << " ";;
				fout << obj[pu]->gtpday() << " ";
				fout << obj[pu]->gtpmonth() << " ";
				fout << obj[pu]->gtpyear() << " ";
				fout << obj[pu]->gtpage() << " ";
				fout << obj[pu]->gtppid() << " ";
				fout << obj[pu]->getid();
				if (pu + 1 != pa)
				{
					fout << endl;
				}
			}
			fout.close();
			ofstream dout;
			dout.open("doctor.txt");
			for (int ht = 0; ht < da; ++ht)
			{
				dout << dbj[ht]->ppname() << " ";
				dout << dbj[ht]->plname() << " ";;
				dout << dbj[ht]->gtpday() << " ";
				dout << dbj[ht]->gtpmonth() << " ";
				dout << dbj[ht]->gtpyear() << " ";
				dout << dbj[ht]->gtpage() << " ";
				dout << dbj[ht]->gtppid() << " ";
				dout << dbj[ht]->gtspeca() << " ";
				dout << dbj[ht]->getdid();
				if (ht + 1 != da)
				{
					dout << endl;
				}
			}
			dout.close();
			ofstream aout;
			
			aout.open("appoint.txt");
			for (int rp = 0; rp < ta; ++rp)
			{
				aout << abj[rp]->getdis() << " ";
				aout << abj[rp]->getptid() << " ";
				aout << abj[rp]->gtd() << " ";
				aout << abj[rp]->gtda() << " ";
				aout << abj[rp]->gtmo() << " ";
				aout << abj[rp]->gtyr() << " ";
				aout << abj[rp]->gttkno() << " ";
				aout << abj[rp]->gtvth() << " ";
				aout << abj[rp]->gtvtm() << " ";
				aout << abj[rp]->gtvts();
				if (rp + 1 != ta)
				{
					aout << endl;
				}
			}
			aout.close();
			ofstream hout;
			hout.open("history.txt");
			for (int jh = 0; jh < da; ++jh)
			{
				if (dbj[jh]->getsat() == 1)
				{
					hout << dbj[jh]->getdid()<<" ";
					for (int to = 0; to < dbj[jh]->getin() - 1; ++to)
					{
						hout << dbj[jh]->gthisto(to) << " ";
					}
					hout << 9;
					if (jh + 1 != da)
					{
						hout << endl;
					}
				}
			}
			hout.close();
			ofstream pout;
			pout.open("patienthistory.txt");
			for (int yt = 0; yt < pa; ++yt)
			{
				if (obj[yt]->gtst() == 1)
				{
					pout << obj[yt]->getid() << " ";
					for (int hj = 0; hj < obj[yt]->rtin() - 1; ++hj)
					{
						pout << obj[yt]->btdi(hj) << " ";
						pout << obj[yt]->btd(hj) << " ";
						pout << obj[yt]->btm(hj) << " ";
						pout << obj[yt]->bty(hj) << " ";
						pout << obj[yt]->btid(hj) << " ";
						pout << obj[yt]->btfes(hj) << " ";
						if ((hj + 1) != (obj[yt]->rtin() - 1))
						{
							if ((obj[yt]->rtin() - 1) >= 2)
							{
								pout << 7 << " ";

							}
						}
					}
					pout << 8;
					if (yt + 1 != pa)
					{
						pout << endl;
					}
				}
			}
			pout.close();
		}
		if (chose == 'c')
		{
			int d, m, y;

			cout << "Enter Date Day ";
			cin >> d;
			cout << "Enter Date month ";
			cin >> m;
			cout << "Enter Year ";
			cin >> y;
		
			for (int mt = 0; mt < pa; ++mt)
			{				
				if (obj[mt]->gtst() == 1)
				{				
					for (int f = 0; f < obj[mt]->rtin()-1; ++f)
					{
							if (obj[mt]->btd(f) == d)
							{
								if (obj[mt]->btm(f) == m)
								{
									if (obj[mt]->bty(f) == y)
									{
										obj[mt]->print();
										obj[mt]->prd(f);
									}
								}
							}						
					}
				}					
			}
		}
		if (chose == 't')
		{
			aq = 100;
		}
		if (chose == 'h')
		{
			for (int a = 0; a < pa; ++a)
			{
				obj[a]->print();
			}
			for (int b = 0; b < da; ++b)
			{
				dbj[b]->print();
			}
		}


		cout << endl;
	}
	

	for (int d = 0; d < da; ++d)
	{
		delete dbj[d];
		cout << "Doctor Closed " << endl;
	}
	for (int e = 0; e < ta; ++e)
	{
		delete abj[e];
		cout << "Appointment CLosed " << endl;
	}
	for (int s = 0; s < pa; ++s)
	{
		delete obj[s];
		cout << "Patient Closed" << endl;
	}

}
















